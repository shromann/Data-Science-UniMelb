from battleground.main import main

main()
